#!/usr/bin/env python3

import pandas as pd
import regex as re
from Bio.Seq import Seq
from pathlib import Path
import typer
import tomli

retrieve_app = typer.Typer()

def demux(pair, seq):
    m = re.match(pair, seq)
    return m.groupdict() if m else None

@retrieve_app.command("run")
def retrieve(
    input_path: str = typer.Option(..., "-i", "--input", help="Input csv file"),
    arrangement_path: str = typer.Option(..., "-a", "--arrangement", help="Arrangement toml file")
):
    
    """
    Retrieve sequences of features of interest.
    """
    
    chunk = []
    chunk_size = 200000
    chunks = pd.read_csv('../regex/mut_lib_duplex_mapped.txt.gz', chunksize=chunk_size, sep='\t', header=None)
    df = pd.concat(chunks, ignore_index=True)
    df = df.rename(columns={0:'read_id',1:'variants_mmi',2:'seq'})
    df_sub = df.head(200000)

    with open(arrangement_path, mode="rb") as fp:
        config_arrangement = tomli.load(fp)

    config_arrangement = pd.DataFrame.from_dict(config_arrangement['arrangements'], orient='index', columns=['value']).reset_index()
    config_arrangement.columns = ['features', 'value']
    print(config_arrangement)
    
    features = ['(?x)']  
    
    for _, row in config_arrangement.iterrows():
        feat = row['features']
        val = row['value']
    
        if isinstance(val, str) and val.isdigit(): # if input is fixed number
            feature = fr"(?P<{feat}>.{{{val}}})"
    
        elif isinstance(val, str) and ',' in val and all(part.strip().isdigit() for part in val.split(',')): # if input is range
            feature = fr"(?P<{feat}>.{{{val}}})"
    
        elif isinstance(val, str): # if input is sequence, fuzzy match with {e<=1}
            feature = fr"(?P<{feat}>{val}){{e<=1}}"
    
        else:
            raise ValueError(f"Unsupported value format for field: {feat} -> {val}")
    
        features.append(feature)
    
    full_features = '\n'.join(features)
    #print(full_features)
    
    df_sub['retseq'] = df_sub['seq'].apply(lambda x: demux(full_features, x)) #retrieve the sequences of each feature
    df_retseq = df_sub[df_sub['retseq'].notna()].reset_index(drop=True)
    df_retseq = df_retseq[['read_id', 'variants_mmi', 'seq', 'retseq']]
    df_retseq_ext = pd.DataFrame(df_retseq['retseq'].values.tolist()) #expand the column that contains the extracted sequences.
    df_retseq_com = pd.concat([df_retseq, df_retseq_ext], axis=1) #paste the read_id info back into the dataframe
    df_retseq_com.to_csv("snipseq_retrieve_output.csv", index=False)
    print("Output saved to snipseq_retrieve_output.csv")
