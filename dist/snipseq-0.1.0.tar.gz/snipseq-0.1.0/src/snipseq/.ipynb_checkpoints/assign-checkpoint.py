#!/usr/bin/env python3 #only activate this if you want to run using python on command line.

import pandas as pd
import numpy as np 
import regex as re # to demultiplex
import subprocess # to run command line in python
from Bio.Seq import Seq
import typer

def assign(
    input_path: str = typer.Option(..., "-i", "--input", help="Input file: 'fastq' or 'pod5'"),
    metadata_path: str = typer.Option(..., "-m", "--metadata", help="Metadata CSV file"),
    sequencing_type: str = typer.Option(..., "-s", "--sequencing_type", help="Sequencing type: 'illumina' or 'nanopore'"),
    read_type: str = typer.Option(None, "-r", "--read_type", help="Read type: 'simplex' or 'duplex' [Required for Nanopore]")
):
    """
    Demultiplex sequencing reads based on single or paired barcode.
    """
    def extract_barcode_matches_short_reads(df, metadata):
        extracted_dfs = []
        count_records = []
    
        for _, row in metadata.iterrows():
            pair_name = row['pair']
            front_barcode = row['front_barcode']
            rear_barcode = row['rear_barcode']
    
            # 1. Find barcode positions using regex
            front_positions = []
            rear_positions = []
    
            for seq in df['seq']:
                fb = re.search(front_barcode, seq)
                if fb:
                    front_positions.append(fb.start())
                rb = re.search(rear_barcode, seq)
                if rb:
                    rear_positions.append(rb.start())
    
            if not front_positions or not rear_positions:
                continue  # skip if no matches found
    
            # 2. Calculate space range
            median_front_pos = np.median(front_positions)
            median_rear_pos = np.median(rear_positions)
            front_len = len(front_barcode)
    
            space_len = median_rear_pos - median_front_pos - front_len
            space_range = f"{int(space_len - 5)}, {int(space_len + 5)}"
    
            # 3. Build regex pattern for this barcode pair
            pattern = fr'''(?x)
            (?P<front>{front_barcode}){{e<=1}}
            (?P<space>.{{{space_range}}})
            (?P<rear>{rear_barcode}){{e<=1}}
            '''
    
            regex = re.compile(pattern)
    
            # 4. Apply pattern to sequences
            col_name = f"extracted_{pair_name}"
    
            df_copy = df.copy()
            df_copy[col_name] = df_copy['seq'].apply(
                lambda x: regex.search(x).groupdict() if regex.search(x) else None
            )
    
            # 5. Filter and expand extracted results
            df_valid = df_copy[df_copy[col_name].notna()].copy()
            extracted_cols = df_valid[col_name].apply(pd.Series)
            df_combined = pd.concat([df_valid.drop(columns=[col_name]), extracted_cols], axis=1)
    
            # 6. Add metadata info
            df_combined['pair'] = pair_name
            df_combined['front_barcode_name'] = row['front_barcode_name']
            df_combined['rear_barcode_name'] = row['rear_barcode_name']
    
            extracted_dfs.append(df_combined)
    
            # 7. Track counts
            count_records.append({
                'pair': pair_name,
                'front_barcode_name': row['front_barcode_name'],
                'rear_barcode_name': row['rear_barcode_name'],
                'front_barcode_seq': front_barcode,
                'rear_barcode_seq': rear_barcode,
                'count': len(df_combined)
            })
    
        # Final outputs
        df_result = pd.concat(extracted_dfs).reset_index(drop=True) if extracted_dfs else pd.DataFrame()
        df_counts = pd.DataFrame(count_records)
    
        return df_result, df_counts

    def extract_barcode_matches_dup(df, metadata):
        extracted_dfs = []
        count_records = []
    
        for _, row in metadata.iterrows():
            pair_name = row['pair']
            front_barcode = row['front_barcode']
            rear_barcode_rc = row['rear_barcode_rc']
    
            # 1. Find barcode positions using regex
            front_positions = []
            rear_positions_rc = []
    
            for seq in df['seq']:
                fb = re.search(front_barcode, seq)
                if fb:
                    front_positions.append(fb.start())
                rb_rc = re.search(rear_barcode_rc, seq)
                if rb_rc:
                    rear_positions_rc.append(rb_rc.start())
    
            if not front_positions or not rear_positions_rc:
                continue  # skip if no matches found
    
            # 2. Calculate space range
            median_front_pos = np.median(front_positions)
            median_rear_rc_pos = np.median(rear_positions_rc)
            front_len = len(front_barcode)
    
            space_len = median_rear_rc_pos - median_front_pos - front_len
            space_range = f"{int(space_len - 5)}, {int(space_len + 5)}"
    
            # 3. Build regex pattern for this barcode pair
            pattern = fr'''(?x)
            (?P<front>{front_barcode}){{e<=1}}
            (?P<space>.{{{space_range}}})
            (?P<rear_rc>{rear_barcode_rc}){{e<=1}}
            '''
    
            regex = re.compile(pattern)
    
            # 4. Apply pattern to sequences
            col_name = f"extracted_{pair_name}"
    
            df_copy = df.copy()
            df_copy[col_name] = df_copy['seq'].apply(
                lambda x: regex.search(x).groupdict() if regex.search(x) else None
            )
    
            # 5. Filter and expand extracted results
            df_valid = df_copy[df_copy[col_name].notna()].copy()
            extracted_cols = df_valid[col_name].apply(pd.Series)
            df_combined = pd.concat([df_valid.drop(columns=[col_name]), extracted_cols], axis=1)
    
            # 6. Add metadata info
            df_combined['pair'] = pair_name
            df_combined['front_barcode_name'] = row['front_barcode_name']
            df_combined['rear_barcode_name'] = row['rear_barcode_name']
    
            extracted_dfs.append(df_combined)
    
            # 7. Track counts
            count_records.append({
                'pair': pair_name,
                'front_barcode_name': row['front_barcode_name'],
                'rear_barcode_name': row['rear_barcode_name'],
                'front_barcode_seq': front_barcode,
                'rear_rc_barcode_seq': rear_barcode_rc,
                'count': len(df_combined)
            })
    
        # Final outputs
        df_result = pd.concat(extracted_dfs).reset_index(drop=True) if extracted_dfs else pd.DataFrame()
        df_counts = pd.DataFrame(count_records)
    
        return df_result, df_counts

    def extract_barcode_matches_sim(df, metadata):
        extracted_dfs = []
        count_records = []

        for _, row in metadata.iterrows():
            pair_name = row['pair']
            front_barcode = row['front_barcode']
            front_barcode_rc = row['front_barcode_rc']
            rear_barcode = row['rear_barcode']
            rear_barcode_rc = row['rear_barcode_rc']
    
            # 1. Find barcode positions using regex
            front_positions = []
            front_positions_rc = []
            rear_positions = []
            rear_positions_rc = []
    
            for seq in df['seq']:
                fb = re.search(front_barcode, seq)
                if fb:
                    front_positions.append(fb.start())
                    
                rb_rc = re.search(rear_barcode_rc, seq)
                if rb_rc:
                    rear_positions_rc.append(rb_rc.start())
                    
                fb_rc = re.search(front_barcode_rc, seq)
                if fb_rc:
                    front_positions_rc.append(fb_rc.start())
                    
                rb = re.search(rear_barcode, seq)
                if rb:
                    rear_positions.append(rb.start())    
                    
    
            if not front_positions or not rear_positions or not front_positions_rc or not rear_positions_rc:
                continue  # skip if no matches found
    
            # 2. Calculate space range using just the forward read (or should I calculate for both fwd and rev reads?)
            median_front_pos = np.median(front_positions)
            median_rear_rc_pos = np.median(rear_positions_rc)
            front_barcode_len = len(front_barcode)
            
            space_len = median_rear_rc_pos - median_front_pos - front_barcode_len
            space_range = f"{int(space_len - 5)}, {int(space_len + 5)}"
    
            # 3. Build regex pattern for this barcode pair
            pattern_fwd = fr'''(?x)
            (?P<front>{front_barcode}){{e<=1}}
            (?P<space>.{{{space_range}}})
            (?P<rear>{rear_barcode_rc}){{e<=1}}
            '''
    
            pattern_rev = fr'''(?x)
            (?P<front>{front_barcode_rc}){{e<=1}}
            (?P<space>.{{{space_range}}})
            (?P<rear>{rear_barcode}){{e<=1}}
            '''
    
            regex_fwd = re.compile(pattern_fwd)
            regex_rev = re.compile(pattern_rev)
            
            # 4. Apply pattern to sequences
            col_name_fwd = f"extracted_{pair_name}_fwd"
            col_name_rev = f"extracted_{pair_name}_rev"
            
            df_copy = df.copy()
            df_copy[col_name_fwd] = df_copy['seq'].apply(lambda x: regex_fwd.search(x).groupdict() if regex_fwd.search(x) else None)
            df_copy[col_name_rev] = df_copy['seq'].apply(lambda x: regex_rev.search(x).groupdict() if regex_rev.search(x) else None)
            
            # 5. Filter and expand extracted results
            df_valid = df_copy[(df_copy[col_name_fwd].notna())| (df_copy[col_name_rev].notna())].copy()
            extracted_cols_fwd = df_valid[col_name_fwd].apply(pd.Series)
            extracted_cols_rev = df_valid[col_name_rev].apply(pd.Series)
            df_combined = pd.concat([df_valid.drop(columns=[col_name_fwd, col_name_rev]), extracted_cols_fwd, extracted_cols_rev], axis=1)
    
            # 6. Add metadata info
            df_combined['pair'] = pair_name
            df_combined['front_barcode_name'] = row['front_barcode_name']
            df_combined['rear_barcode_name'] = row['rear_barcode_name']
    
            extracted_dfs.append(df_combined)
    
            # 7. Track counts
            count_records.append({
                'pair': pair_name,
                'front_barcode_name': row['front_barcode_name'],
                'rear_barcode_name': row['rear_barcode_name'],
                'front_barcode_seq': front_barcode,
                'rear_barcode_seq': rear_barcode_rc,
                'count': len(df_combined)
            })
    
        # Final outputs
        df_result_sim = pd.concat(extracted_dfs).reset_index(drop=True) if extracted_dfs else pd.DataFrame()
        df_counts_sim = pd.DataFrame(count_records)
    
        return df_result_sim, df_counts_sim

    #load users' metadata
    metadata = pd.read_csv(metadata_path,sep=',',header=0)
    metadata['front_barcode_rc'] = metadata['front_barcode'].apply(lambda x: str(Seq(x).reverse_complement()))
    metadata['rear_barcode_rc'] = metadata['rear_barcode'].apply(lambda x: str(Seq(x).reverse_complement()))
    # metadata['pair_num'] = metadata['pair'].apply(lambda x: int(x.replace("pair", "")))
    # pair_list = metadata['pair_num'].tolist()

    #to determine the best chunksize
    # Sample the first N rows to estimate average memory per row
    sample_n = 100000  # larger sample gives better estimate; adjust if needed
    df_sample = pd.read_csv(input_path, nrows=sample_n, sep="\t", header=None)

    # Estimate memory per row
    avg_per_row_bytes = df_sample.memory_usage(deep=True).sum() / len(df_sample)
    
    # Set memory budget for each chunk (e.g., 500 MB)
    mem_limit_bytes = 500 * 1024 * 1024
    
    ideal_chunk_size = max(1, int(mem_limit_bytes / avg_per_row_bytes))

    sequencing_type = sequencing_type.lower() #this makes sure it is lowercase

    # Validate sequencing type
    if sequencing_type not in ["illumina", "nanopore"]:
        typer.echo("Error: --sequencing_type must be 'illumina' or 'nanopore'.")
        raise typer.Exit(code=1)

    if sequencing_type == "nanopore":
        if not read_type:
            typer.echo("Error: --read_type is required for nanopore.")
            raise typer.Exit(code=1)
            
        read_type = read_type.lower() #this makes sure it is lowercase
        
        df_results = []
        df_counts_list = []

        # There can be two types of input for nanopore, either a pod5 file or a fastq file. 
        # If input is pod5, snipseq will do basecalling using dorado and users need to specify in the argument whether they want to run a simplex or duplex basecalling. 
        if input_path == "pod5":
            if read_type == "simplex":
                subprocess.run(f"dorado basecaller hac {input_path} > simplex.bam", shell=True, check=True)
                subprocess.run("samtools view -F2304 simplex.bam | "
                               "awk '{print $1 \"\\t\" $10}' | "
                               "gzip > simplex.txt.gz", shell=True, check=True)

                for chunk in pd.read_csv('simplex.txt.gz', chunksize=ideal_chunk_size, sep='\t', header=None):
                    chunk = chunk.rename(columns={0:'read_id',1:'seq'})
                    df_result, df_counts = extract_barcode_matches_sim(chunk, metadata)
                    df_results.append(df_result)
                    df_counts_list.append(df_counts)
                
            elif read_type == "duplex":
                subprocess.run(f"dorado duplex sup {input_path} > duplex.bam", shell=True, check=True)
                subprocess.run(
                    "samtools view -F2304 duplex.bam | "
                    "awk '/dx:i:1/ || /dx:i:0/ {print $1 \"\\t\" $10}' | "
                    "gzip > duplex.txt.gz", shell=True, check=True)

                for chunk in pd.read_csv('duplex.txt.gz', chunksize=ideal_chunk_size, sep='\t', header=None):
                    chunk = chunk.rename(columns={0: 'read_id', 1: 'seq'})
                    df_result, df_counts = extract_barcode_matches_dup(chunk, metadata)
                    df_results.append(df_result)
                    df_counts_list.append(df_counts)

            else:
                typer.echo("Error: read_type must be 'simplex' or 'duplex'.")
                raise typer.Exit(code=1)
            
        # If the input is a fastq, this command will be executed instead. 
        elif input_path == "fastq":  # assuming all fastq files from users are simplex for now, because I am not sure how duplex fastq looks like.
            subprocess.run(
                f"zcat {input_path} | "
                "awk 'NR % 4 == 1 {read_id = gensub(/^@([^ ]+).*/, \"\\1\", \"g\")} NR % 4 == 2 {print read_id \"\\t\" $0}' | gzip > simplex.txt.gz", shell=True, check=True)

        # Concatenate all results and counts after processing all chunks
        final_df_result = pd.concat(df_results, ignore_index=True)
        final_df_counts = pd.concat(df_counts_list, ignore_index=True)
        
        #as_index=False makes sure that the pairs column stays as a column instead of an index
        #this step is to group the pairs together because they were separated when reading in by chunks
        final_df_counts = final_df_counts.groupby(['pair','front_barcode_name', 'rear_barcode_name',
                                                   'front_barcode_seq','rear_rc_barcode_seq'], as_index=False)['count'].sum()
    
    # need to download illumina sequencing datasets to try still in progress
    elif sequencing_type == "illumina": #still in progress
        
        df_results = []
        df_counts_list = []
        
        for chunk in pd.read_csv(input_path, chunksize=ideal_chunk_size, sep='\t', header=None):
            chunk = chunk.rename(columns={0:'read_id',1:'seq'})
            df_result, df_counts = extract_barcode_matches_short_reads(chunk, metadata)
            df_results.append(df_result)
            df_counts_list.append(df_counts)
            
        final_df_result = pd.concat(df_results, ignore_index=True)
        final_df_counts = pd.concat(df_counts_list, ignore_index=True)
        
    final_df_result.to_csv("snipseq_assign.csv", index=False)
    print("Demultiplexing complete. Main output saved to snipseq_assign.csv")
    final_df_counts.to_csv("snipseq_assign_counts.csv", index=False)
    print("Demultiplexing complete. Counts output saved to snipseq_assign_counts.csv")