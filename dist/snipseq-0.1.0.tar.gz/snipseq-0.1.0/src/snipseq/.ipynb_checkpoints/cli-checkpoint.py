
import typer
from .assign import assign

app = typer.Typer(help="snipseq: demultiplex sequencing reads by barcode pairs.")

# Register the function as a command
app.command()(assign)

if __name__ == "__main__":
    app()
